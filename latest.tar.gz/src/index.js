/**
 *  Entry
 *  Require your scripts here and start them!
 */
var log = require('logger');

log('Hello World!');